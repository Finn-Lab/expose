# embl_biotransform

A small, extensible pipeline that integrates evidence from EMBL-EBI /
SIB resources to predict the biotransformation capabilities of a
metagenome sample, and shows the evidence behind each prediction.

## The data model

Three kinds of input, as specified:

1. **Reference biotransformation data**, tied to either an individual
   **microbe** or an individual **gene/enzyme**. There's no single EMBL
   API that packages this directly, so it's supplied as a file
   (`reference.py` loads JSON or CSV) -- see
   `example_data/reference_associations.json`. In practice you'd build
   this by combining literature curation with lookups against
   [UniProt](https://www.uniprot.org) (gene → EC number → organism) and
   [Rhea](https://www.rhea-db.org) (EC number → reaction).
2. **A metagenome analysis**, giving both:
   - which **microbes** are present (taxonomic profile), and
   - which **enzymes/functional families** are present (functional
     annotation) -- from [MGnify](https://www.ebi.ac.uk/metagenomics),
     EMBL-EBI's metagenomics resource.
3. **Evidence tiering**, exactly as described: an **enzyme detected
   directly** in the metagenome is the strongest evidence for
   biotransformation activity (**Tier 1**); a **microbe's presence**
   alone, without its specific enzyme being confirmed, is weaker,
   inferred evidence (**Tier 2**).

## Architecture

```
fetchers.py       -- ChEBI / Rhea / UniProt / ChEMBL / MGnify (v1, plain requests) clients.
                      Each supports both a live fetch() and a load_file() for offline/reproducible runs.
mgnipy_client.py   -- MGnipySource: adapter over `mgnipy` (https://github.com/EBI-Metagenomics/mgnipy),
                      the official client for MGnify API v2. Optional dependency.
reference.py       -- loads curated per-microbe / per-gene biotransformation associations (JSON/CSV).
integrate.py       -- EvidenceGraph: a typed, evidence-annotated networkx graph tying together
                      sample -> detected taxa / functional annotations -> reference associations
                      -> reaction classes (-> substrate compound, where known).
predict.py         -- BiotransformationPredictor: scores each reaction class per sample using the
                      Tier-1 (enzyme) / Tier-2 (microbe) evidence model, with the full trail kept.
visualize.py        -- plot_evidence_graph (the network, Tier 1 vs Tier 2 visibly marked) and
                      plot_evidence_scores (ranked confidence bar chart, annotated with hit counts).
```

Every edge in the graph carries a `source` and an `evidence` string, so
every prediction is traceable back to exactly which detection(s) and
which curated statement(s) produced it -- nothing is a black box.

## Interface: Jupyter notebook

`biotransformation_explorer.ipynb` is the interactive front end. It lets
a user:

1. Pick a data source: live MGnify (via `mgnipy`, API v2) with a study
   search → analysis picker, or point at previously-downloaded JSON
   files (`example_data/sample_taxonomy.json`,
   `example_data/sample_functions.json` are provided as a worked
   example).
2. Point at a reference-associations file.
3. Run the integration + prediction step.
4. See the evidence graph and the ranked, annotated confidence chart
   inline.

`mgnipy` is a young, actively-evolving package -- if a call in
`mgnipy_client.py` no longer matches its current API, check
https://mgnipy.mgnify.org/. The shape of what comes back downstream (a
list of `{organism, source, evidence}` / `{annotation_id, description,
source, evidence}` dicts) is what `integrate.py` actually depends on, so
you can adjust the mgnipy calls without touching anything else.

## Quick start (offline, using the bundled example data)

```python
from embl_biotransform import (
    EvidenceGraph, BiotransformationPredictor, load_reference_associations,
    plot_evidence_graph, plot_evidence_scores,
)
import json

taxa = json.load(open("example_data/sample_taxonomy.json"))
functions = json.load(open("example_data/sample_functions.json"))
references = load_reference_associations("example_data/reference_associations.json")

graph = EvidenceGraph()
sample = graph.add_sample("demo-sample")
graph.add_detected_taxa(sample, taxa)
graph.add_detected_functions(sample, functions)
graph.add_reference_associations(references)
graph.link_detections_to_references()

predictions = BiotransformationPredictor(graph).predict(sample)
for p in predictions:
    print(p.reaction_class, p.score, p.confidence_label)

plot_evidence_graph(graph, sample_node=sample, save_path="graph.png")
plot_evidence_scores(predictions, save_path="scores.png")
```

Or open `biotransformation_explorer.ipynb` for the interactive version.

## Extending this

- **Matching logic**: `EvidenceGraph.link_detections_to_references`
  currently matches a reference's EC/KO/InterPro id or a distinctive
  word from its name against the detected function's id/description
  (functional annotations are often reported by family name, not EC
  number). Tighten this (e.g. exact InterPro/KO id matching) once you
  know which functional-annotation pipeline your MGnify analyses use.
- **Scoring**: `BiotransformationPrediction.score` in `predict.py` is a
  simple, documented heuristic (Tier-1 dominates, Tier-2 caps lower,
  convergence gets a bonus) -- swap in a different weighting, or a proper
  statistical model, without touching the graph or the notebook.
- **More reference sources**: `fetchers.py` already includes ChEBI (compound
  structure) and Rhea (EC ↔ reaction) clients so you can auto-populate
  parts of the reference file from UniProt + Rhea instead of hand-curating
  it, for genes with a known EC number.
- **Substrate structure**: `ChEBIClient` returns SMILES for a compound;
  if you install `rdkit` you can add structural-alert matching (e.g. via
  SMARTS patterns for known biotransformation sites) as a third,
  independent line of evidence alongside Tier 1 / Tier 2.

## Requirements

See `requirements.txt`. `rdkit` and `mgnipy` are optional: the pipeline
runs fully offline against files without either of them installed.
