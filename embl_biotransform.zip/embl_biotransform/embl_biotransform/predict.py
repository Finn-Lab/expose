"""
predict.py
==========

Scores candidate biotransformations for a metagenome sample using the
two-tier evidence model:

  Tier 1 (strongest) -- the specific ENZYME/gene behind a reference
                         association was directly detected in the sample's
                         functional annotation.
  Tier 2 (weaker)     -- a MICROBE known (from the reference data) to carry
                         out the reaction is present in the sample's
                         taxonomic profile, but its enzyme was not
                         independently confirmed there.

A reaction class can accumulate both kinds of evidence (e.g. three
supporting microbes and one directly-detected enzyme); agreement across
independent references and across tiers raises confidence, matching the
idea that convergent, independent evidence is stronger than any single
line of it.

Nothing here claims certainty -- every prediction keeps its full evidence
trail (which detections + which curated reference statements produced it)
so a human can audit the basis for the call.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .integrate import EvidenceGraph


@dataclass
class BiotransformationPrediction:
    reaction_class: str
    tier1_hits: list[dict] = field(default_factory=list)  # enzyme-level, directly detected
    tier2_hits: list[dict] = field(default_factory=list)  # microbe-level, inferred
    substrate_chebi: str | None = None

    @property
    def score(self) -> float:
        """0-1 confidence.
        - Any Tier-1 (enzyme-detected) hit dominates the score; multiple
          independent Tier-1 hits push it toward 1.0.
        - Tier-2-only (microbe-present) support caps out lower, reflecting
          that the specific catalytic machinery wasn't itself confirmed.
        - Having both tiers agree on the same reaction class adds a small
          convergence bonus on top of the Tier-1 base.
        """
        t1 = min(len(self.tier1_hits), 3) / 3        # 0..1
        t2 = min(len(self.tier2_hits), 3) / 3          # 0..1
        if self.tier1_hits:
            base = 0.6 + 0.3 * t1                       # 0.6 - 0.9
            bonus = 0.1 if self.tier2_hits else 0.0      # convergence bonus
            return round(min(base + bonus, 1.0), 3)
        # microbe evidence only
        return round(0.15 + 0.35 * t2, 3)                # 0.15 - 0.5

    @property
    def confidence_label(self) -> str:
        if self.tier1_hits:
            return ("high - enzyme directly detected in metagenome"
                     + (", corroborated by microbe presence" if self.tier2_hits else ""))
        return "moderate/low - inferred only from microbe presence (enzyme not confirmed)"

    @property
    def evidence_summary(self) -> list[str]:
        lines = []
        for h in self.tier1_hits:
            lines.append(f"[Tier 1 / enzyme] {h['entity_name']} ({h['entity_id']}) detected in sample "
                         f"via functional annotation matching '{h.get('_matched_function', '?')}'.")
        for h in self.tier2_hits:
            lines.append(f"[Tier 2 / microbe] {h['entity_name']} detected in sample's taxonomic profile "
                         f"(enzyme itself not confirmed).")
        return lines


class BiotransformationPredictor:
    """Given an EvidenceGraph that already has a sample's detections and the
    reference associations loaded and linked (`link_detections_to_references`),
    produce ranked, evidence-backed biotransformation predictions."""

    def __init__(self, graph: EvidenceGraph):
        self.graph = graph

    def predict(self, sample_node: str) -> list[BiotransformationPrediction]:
        g = self.graph.graph
        detected_taxa = {n for n in g.successors(sample_node) if g.nodes[n].get("type") == "taxon"}
        detected_funcs = {n for n in g.successors(sample_node) if g.nodes[n].get("type") == "functional_annotation"}

        by_reaction: dict[str, BiotransformationPrediction] = {}

        for ref_node, rdata in g.nodes(data=True):
            if rdata.get("type") != "reference":
                continue
            reaction_class = rdata["reaction_class"]
            pred = by_reaction.setdefault(
                reaction_class,
                BiotransformationPrediction(reaction_class=reaction_class,
                                             substrate_chebi=rdata.get("chebi_substrate")),
            )

            # who points at this reference node with an "integration" edge
            # that originates from something this sample actually detected?
            for pred_node in g.predecessors(ref_node):
                edge_datas = g.get_edge_data(pred_node, ref_node).values()
                if not any(e.get("source") == "integration" for e in edge_datas):
                    continue
                if rdata["entity_type"] == "gene" and pred_node in detected_funcs:
                    hit = dict(rdata)
                    hit["_matched_function"] = g.nodes[pred_node].get("description")
                    pred.tier1_hits.append(hit)
                elif rdata["entity_type"] == "microbe" and pred_node in detected_taxa:
                    pred.tier2_hits.append(dict(rdata))

        # only keep reaction classes with at least one hit in *this* sample
        predictions = [p for p in by_reaction.values() if p.tier1_hits or p.tier2_hits]
        return sorted(predictions, key=lambda p: p.score, reverse=True)
