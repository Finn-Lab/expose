"""
integrate.py
============

Builds one evidence graph out of:

- a metagenome **sample** and what MGnify detected in it (taxa + functional
  annotations),
- the curated **reference associations** (per-microbe or per-gene
  biotransformation statements) from `reference.py`,
- optionally, ChEBI/Rhea/UniProt records for extra compound/reaction
  context.

Node types: sample, taxon, functional_annotation, reference (a curated
microbe- or gene-level association), reaction_class, compound.

Edges always carry `source` and `evidence`, so any prediction can be traced
back to exactly which detection(s) and which curated statement(s) produced
it -- this is what `predict.py` reasons over and `visualize.py` displays.
"""

from __future__ import annotations

import networkx as nx


class EvidenceGraph:
    def __init__(self) -> None:
        self.graph = nx.MultiDiGraph()

    # -- metagenome side ---------------------------------------------------- #

    def add_sample(self, sample_id: str, **meta) -> str:
        node = f"sample:{sample_id}"
        self.graph.add_node(node, type="sample", sample_id=sample_id, **meta)
        return node

    def add_detected_taxa(self, sample_node: str, taxa: list[dict]) -> list[str]:
        nodes = []
        for t in taxa:
            tnode = f"taxon:{t.get('organism')}"
            self.graph.add_node(tnode, type="taxon", **t)
            self.graph.add_edge(sample_node, tnode, source=t["source"], evidence=t["evidence"])
            nodes.append(tnode)
        return nodes

    def add_detected_functions(self, sample_node: str, annotations: list[dict]) -> list[str]:
        nodes = []
        for a in annotations:
            anode = f"func:{a.get('annotation_id') or a.get('description')}"
            self.graph.add_node(anode, type="functional_annotation", **a)
            self.graph.add_edge(sample_node, anode, source=a["source"], evidence=a["evidence"])
            nodes.append(anode)
        return nodes

    # -- reference (curated) side -------------------------------------------- #

    def add_reference_associations(self, references: list[dict]) -> list[str]:
        """Adds curated microbe-/gene-level biotransformation statements and
        links them to a shared `reaction_class` node so multiple lines of
        evidence for the same reaction converge on one place."""
        nodes = []
        for ref in references:
            rnode = f"ref:{ref['entity_type']}:{ref['entity_id']}:{ref['reaction_class']}"
            self.graph.add_node(rnode, type="reference", tier=1 if ref["entity_type"] == "gene" else 2, **ref)

            rc_node = f"reaction_class:{ref['reaction_class']}"
            self.graph.add_node(rc_node, type="reaction_class", name=ref["reaction_class"])
            self.graph.add_edge(rnode, rc_node, source=ref["source"], evidence=ref["evidence"])

            if ref.get("chebi_substrate"):
                cnode = f"compound:{ref['chebi_substrate']}"
                self.graph.add_node(cnode, type="compound", chebi_id=ref["chebi_substrate"])
                self.graph.add_edge(rc_node, cnode, source=ref["source"],
                                     evidence=f"Reaction class acts on {ref['chebi_substrate']}.")
            nodes.append(rnode)
        return nodes

    # -- linking detections to references ------------------------------------ #

    def link_detections_to_references(self) -> None:
        """Connects sample-level detections (taxa / functional annotations)
        to matching reference nodes by simple id/name match. This is the
        step that turns 'what was detected' + 'what is known' into
        traceable evidence for `predict.py`."""
        taxon_nodes = {d["organism"]: n for n, d in self.graph.nodes(data=True) if d.get("type") == "taxon"}
        func_nodes = [(n, d) for n, d in self.graph.nodes(data=True) if d.get("type") == "functional_annotation"]
        ref_nodes = [(n, d) for n, d in self.graph.nodes(data=True) if d.get("type") == "reference"]

        for rnode, rdata in ref_nodes:
            if rdata["entity_type"] == "microbe":
                match = taxon_nodes.get(rdata["entity_id"])
                if match:
                    self.graph.add_edge(match, rnode, source="integration",
                                         evidence=f"Detected taxon matches reference microbe '{rdata['entity_id']}'.")
            else:  # gene
                entity_key = rdata["entity_id"].split(":")[-1].lower()
                name_words = [w for w in rdata.get("entity_name", "").lower().split() if len(w) >= 3]
                for fnode, fdata in func_nodes:
                    ident = (str(fdata.get("annotation_id", "")) + " " + str(fdata.get("description", ""))).lower()
                    # match either the reference's id (EC/KO/InterPro number) directly against the
                    # annotation id/description, or a distinctive word from its name (e.g. "AlkB") --
                    # functional annotations are often reported by family name rather than EC number.
                    if entity_key in ident or any(w in ident for w in name_words):
                        self.graph.add_edge(fnode, rnode, source="integration",
                                             evidence=f"Detected function matches reference gene '{rdata['entity_id']}'.")

    # -- querying ------------------------------------------------------------ #

    def evidence_trail(self, source_node: str, target_node: str, cutoff: int = 4) -> list[list[dict]]:
        trails = []
        for path in nx.all_simple_edge_paths(self.graph, source_node, target_node, cutoff=cutoff):
            trail = []
            for u, v, k in path:
                edge = self.graph.edges[u, v, k]
                trail.append({"from": u, "to": v, "source": edge["source"], "evidence": edge["evidence"]})
            trails.append(trail)
        return trails

    def summary(self) -> dict:
        by_type: dict[str, int] = {}
        for _, data in self.graph.nodes(data=True):
            by_type[data.get("type", "?")] = by_type.get(data.get("type", "?"), 0) + 1
        return {"nodes": self.graph.number_of_nodes(), "edges": self.graph.number_of_edges(), "by_type": by_type}
