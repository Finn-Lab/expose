"""
fetchers.py
===========

Thin clients for the EMBL-EBI / SIB resources used to build biotransformation
evidence:

- ChEBI      (compound identity, structure, formula)          https://www.ebi.ac.uk/chebi/backend/api/public
- Rhea       (curated biochemical reactions, ChEBI <-> EC)     https://www.rhea-db.org/help/rest-api
- UniProt    (enzymes / proteins catalysing those EC numbers)  https://rest.uniprot.org
- ChEMBL     (bioactivity / metabolism evidence)                https://www.ebi.ac.uk/chembl/api/data

Every client supports two interchangeable modes, chosen per-call:

1. Live API      -- `fetch(...)` hits the network (requires network access).
2. Local file     -- `load_file(path)` reads a previously-downloaded JSON/TSV
                     response, so the pipeline runs fully offline and is
                     reproducible / testable without hammering the APIs.

Each client normalises its raw response into a small list of plain dicts
("records") with a common shape so `integrate.py` doesn't need to know the
source-specific formats. Every record carries a `source` and `evidence`
field, which is what the graph and the plots use to justify a prediction.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

import requests


class EMBLAPIError(RuntimeError):
    """Raised when a live API call fails after retries."""


def _get_json(url: str, params: dict | None = None, timeout: int = 20,
               retries: int = 3, backoff: float = 1.5) -> Any:
    headers = {"User-Agent": "embl-biotransform/0.1 (research tool)"}
    last_exc: Exception | None = None
    for attempt in range(retries):
        try:
            resp = requests.get(url, params=params, headers=headers, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
        except Exception as exc:  # noqa: BLE001 - we want to retry broadly, then surface
            last_exc = exc
            time.sleep(backoff ** attempt)
    raise EMBLAPIError(f"GET {url} failed after {retries} attempts: {last_exc}")


def _get_text(url: str, params: dict | None = None, timeout: int = 20,
              retries: int = 3, backoff: float = 1.5) -> str:
    headers = {"User-Agent": "embl-biotransform/0.1 (research tool)"}
    last_exc: Exception | None = None
    for attempt in range(retries):
        try:
            resp = requests.get(url, params=params, headers=headers, timeout=timeout)
            resp.raise_for_status()
            return resp.text
        except Exception as exc:  # noqa: BLE001
            last_exc = exc
            time.sleep(backoff ** attempt)
    raise EMBLAPIError(f"GET {url} failed after {retries} attempts: {last_exc}")


def _parse_tsv(text: str) -> list[dict[str, str]]:
    lines = [ln for ln in text.splitlines() if ln.strip()]
    if not lines:
        return []
    header = lines[0].split("\t")
    return [dict(zip(header, ln.split("\t"))) for ln in lines[1:]]


# --------------------------------------------------------------------------- #
# ChEBI
# --------------------------------------------------------------------------- #

class ChEBIClient:
    """Compound identity / structure lookups against ChEBI."""

    BASE_URL = "https://www.ebi.ac.uk/chebi/backend/api/public"

    def fetch_compound(self, chebi_id: str) -> dict:
        """Fetch one compound record by ChEBI id (e.g. 'CHEBI:17234' or '17234')."""
        cid = chebi_id.split(":")[-1]
        data = _get_json(f"{self.BASE_URL}/compounds/{cid}/")
        return self._normalise(data)

    def load_file(self, path: str | Path) -> dict:
        data = json.loads(Path(path).read_text())
        return self._normalise(data)

    @staticmethod
    def _normalise(data: dict) -> dict:
        struct = data.get("default_structure") or {}
        chem = data.get("chemical_data") or {}
        return {
            "source": "ChEBI",
            "chebi_id": f"CHEBI:{data.get('id') or data.get('chebi_accession', '')}".replace("CHEBI:CHEBI", "CHEBI"),
            "name": data.get("name") or data.get("ascii_name"),
            "smiles": struct.get("smiles"),
            "formula": chem.get("formula"),
            "mass": chem.get("mass"),
            "evidence": "ChEBI compound record (curated chemical entity).",
        }


# --------------------------------------------------------------------------- #
# Rhea
# --------------------------------------------------------------------------- #

class RheaClient:
    """Reactions a compound participates in, linked to EC numbers."""

    BASE_URL = "https://www.rhea-db.org/rhea"

    def fetch_reactions_for_chebi(self, chebi_id: str, limit: int = 25) -> list[dict]:
        cid = chebi_id if chebi_id.upper().startswith("CHEBI:") else f"CHEBI:{chebi_id}"
        params = {
            "query": cid,
            "columns": "rhea-id,equation,chebi-id,ec",
            "format": "tsv",
            "limit": limit,
        }
        text = _get_text(self.BASE_URL, params=params)
        return self._normalise(_parse_tsv(text))

    def load_file(self, path: str | Path) -> list[dict]:
        text = Path(path).read_text()
        # accept either a raw TSV dump or a JSON list of the same rows
        try:
            rows = json.loads(text)
        except json.JSONDecodeError:
            rows = _parse_tsv(text)
        return self._normalise(rows)

    @staticmethod
    def _normalise(rows: Iterable[dict]) -> list[dict]:
        out = []
        for row in rows:
            ec_field = row.get("EC") or row.get("ec") or ""
            ec_numbers = [e.strip() for e in ec_field.replace("EC:", "").split(";") if e.strip()]
            out.append({
                "source": "Rhea",
                "rhea_id": row.get("RHEA ID") or row.get("rhea-id") or row.get("Reaction identifier"),
                "equation": row.get("Equation") or row.get("equation"),
                "chebi_participants": row.get("ChEBI identifier") or row.get("chebi-id"),
                "ec_numbers": ec_numbers,
                "evidence": "Curated reaction in Rhea (SIB/EMBL-EBI), links compound to EC number(s).",
            })
        return out


# --------------------------------------------------------------------------- #
# UniProt
# --------------------------------------------------------------------------- #

class UniProtClient:
    """Enzymes (reviewed Swiss-Prot entries) catalysing a given EC number."""

    BASE_URL = "https://rest.uniprot.org/uniprotkb/search"

    def fetch_enzymes_for_ec(self, ec_number: str, limit: int = 10,
                              reviewed_only: bool = True) -> list[dict]:
        query = f"ec:{ec_number}"
        if reviewed_only:
            query += " AND reviewed:true"
        params = {
            "query": query,
            "fields": "accession,protein_name,gene_names,organism_name,ec,cc_function",
            "format": "json",
            "size": limit,
        }
        data = _get_json(self.BASE_URL, params=params)
        return self._normalise(data.get("results", []))

    def load_file(self, path: str | Path) -> list[dict]:
        data = json.loads(Path(path).read_text())
        results = data.get("results", data) if isinstance(data, dict) else data
        return self._normalise(results)

    @staticmethod
    def _normalise(results: Iterable[dict]) -> list[dict]:
        out = []
        for r in results:
            protein_desc = (r.get("proteinDescription", {}) or {})
            rec_name = (protein_desc.get("recommendedName", {}) or {}).get("fullName", {}) or {}
            genes = r.get("genes", []) or []
            gene_name = (genes[0].get("geneName", {}) or {}).get("value") if genes else None
            organism = (r.get("organism", {}) or {}).get("scientificName")
            out.append({
                "source": "UniProt",
                "accession": r.get("primaryAccession"),
                "protein_name": rec_name.get("value"),
                "gene_name": gene_name,
                "organism": organism,
                "evidence": "Reviewed (Swiss-Prot) enzyme annotated with the matching EC number.",
            })
        return out


# --------------------------------------------------------------------------- #
# ChEMBL
# --------------------------------------------------------------------------- #

class ChEMBLClient:
    """Bioactivity / metabolism-related evidence for a compound."""

    BASE_URL = "https://www.ebi.ac.uk/chembl/api/data"

    def fetch_metabolism_activities(self, chembl_molecule_id: str, limit: int = 25) -> list[dict]:
        params = {
            "molecule_chembl_id": chembl_molecule_id,
            "format": "json",
            "limit": limit,
        }
        data = _get_json(f"{self.BASE_URL}/activity.json", params=params)
        return self._normalise(data.get("activities", []))

    def load_file(self, path: str | Path) -> list[dict]:
        data = json.loads(Path(path).read_text())
        activities = data.get("activities", data) if isinstance(data, dict) else data
        return self._normalise(activities)

    @staticmethod
    def _normalise(activities: Iterable[dict]) -> list[dict]:
        out = []
        for a in activities:
            out.append({
                "source": "ChEMBL",
                "assay_description": a.get("assay_description"),
                "target_organism": a.get("target_organism"),
                "standard_type": a.get("standard_type"),
                "standard_value": a.get("standard_value"),
                "standard_units": a.get("standard_units"),
                "evidence": "Bioactivity assay result that may reflect metabolic turnover or clearance.",
            })
        return out

# --------------------------------------------------------------------------- #
# MGnify (metagenome taxonomy + functional annotation)
# --------------------------------------------------------------------------- #

class MGnifyClient:
    """Metagenome analysis results from MGnify (EMBL-EBI): which microbes
    (taxonomy) and which enzyme/functional families (InterPro / KEGG
    Orthologs / EC, depending on the pipeline version) were detected in a
    given sample analysis.

    An "analysis accession" looks like 'MGYA00585482'. Taxonomy and
    functional annotation are separate endpoints under the same analysis.
    """

    BASE_URL = "https://www.ebi.ac.uk/metagenomics/api/v1"

    def fetch_taxonomy(self, analysis_id: str, rna_type: str = "ssu",
                        page_size: int = 100) -> list[dict]:
        url = f"{self.BASE_URL}/analyses/{analysis_id}/taxonomy/{rna_type}"
        data = _get_json(url, params={"page_size": page_size})
        return self._normalise_taxonomy(data.get("data", []))

    def fetch_functional_annotations(self, analysis_id: str,
                                      kind: str = "interpro-identifiers",
                                      page_size: int = 100) -> list[dict]:
        """`kind` is one of MGnify's functional-annotation endpoints, e.g.
        'interpro-identifiers', 'kegg-modules', 'go-slim'."""
        url = f"{self.BASE_URL}/analyses/{analysis_id}/{kind}"
        data = _get_json(url, params={"page_size": page_size})
        return self._normalise_functional(data.get("data", []))

    def load_taxonomy_file(self, path: str | Path) -> list[dict]:
        data = json.loads(Path(path).read_text())
        rows = data.get("data", data) if isinstance(data, dict) else data
        return self._normalise_taxonomy(rows)

    def load_functional_file(self, path: str | Path) -> list[dict]:
        data = json.loads(Path(path).read_text())
        rows = data.get("data", data) if isinstance(data, dict) else data
        return self._normalise_functional(rows)

    @staticmethod
    def _normalise_taxonomy(rows: Iterable[dict]) -> list[dict]:
        out = []
        for item in rows:
            attrs = item.get("attributes", item)
            out.append({
                "source": "MGnify",
                "taxon_id": item.get("id"),
                "organism": attrs.get("name") or attrs.get("lineage"),
                "abundance": attrs.get("count") or attrs.get("relative-abundance"),
                "evidence": "Taxon detected in the metagenome's rRNA-based taxonomic profile (MGnify).",
            })
        return out

    @staticmethod
    def _normalise_functional(rows: Iterable[dict]) -> list[dict]:
        out = []
        for item in rows:
            attrs = item.get("attributes", item)
            out.append({
                "source": "MGnify",
                "annotation_id": item.get("id"),
                "description": attrs.get("description") or attrs.get("name"),
                "abundance": attrs.get("count"),
                "evidence": "Functional/enzyme family directly detected in the metagenome's gene annotation (MGnify).",
            })
        return out
