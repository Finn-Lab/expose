"""
reference.py
============

Loads the curated "ground truth" biotransformation associations that anchor
everything else: statements of the form "this microbe" or "this gene/enzyme"
is known to carry out "this biotransformation". No single EMBL-EBI API
packages this directly, so it is supplied as a file (JSON or CSV) -- built,
for example, by combining literature curation with UniProt (gene -> EC ->
organism) and Rhea (EC -> reaction) lookups.

Each association is one of two kinds, matching the two ways biotransformation
evidence was described:

- entity_type == "gene"    : tied to a specific enzyme/gene. Matched against
                              a metagenome's *functional* annotation
                              (EC / KO / InterPro id). This is the strongest
                              (Tier 1) evidence when it's directly detected.
- entity_type == "microbe" : tied to an organism/taxon. Matched against a
                              metagenome's *taxonomic* profile. This is
                              weaker (Tier 2) evidence -- the organism is
                              present, but its specific enzyme wasn't
                              independently confirmed in this sample.

Expected JSON shape (a list of records):
[
  {
    "entity_type": "gene",
    "entity_id": "EC:1.14.14.1",        # or a KO/InterPro id
    "entity_name": "CYP153 alkane hydroxylase",
    "reaction_class": "Alkane hydroxylation",
    "chebi_substrate": "CHEBI:138366",   # optional, e.g. dodecane
    "source": "Literature / UniProt",
    "evidence": "Characterised alkane omega-hydroxylase (PMID:...)."
  },
  {
    "entity_type": "microbe",
    "entity_id": "Pseudomonas putida",
    "entity_name": "Pseudomonas putida",
    "reaction_class": "Alkane hydroxylation",
    "chebi_substrate": "CHEBI:138366",
    "source": "Literature",
    "evidence": "Reported to degrade medium-chain alkanes (PMID:...)."
  }
]

CSV files use the same column names as the JSON keys above.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path


REQUIRED_FIELDS = {"entity_type", "entity_id", "reaction_class"}


def load_reference_associations(path: str | Path) -> list[dict]:
    path = Path(path)
    if path.suffix.lower() == ".json":
        records = json.loads(path.read_text())
    elif path.suffix.lower() == ".csv":
        with path.open(newline="") as f:
            records = list(csv.DictReader(f))
    else:
        raise ValueError(f"Unsupported reference file type: {path.suffix} (use .json or .csv)")

    for rec in records:
        missing = REQUIRED_FIELDS - rec.keys()
        if missing:
            raise ValueError(f"Reference record missing required field(s) {missing}: {rec}")
        if rec["entity_type"] not in ("gene", "microbe"):
            raise ValueError(f"entity_type must be 'gene' or 'microbe', got {rec['entity_type']!r}")
        rec.setdefault("source", "user-supplied reference file")
        rec.setdefault("evidence", f"Curated association: {rec['entity_id']} -> {rec['reaction_class']}.")
        rec.setdefault("entity_name", rec["entity_id"])

    return records
