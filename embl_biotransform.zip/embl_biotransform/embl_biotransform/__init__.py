"""
embl_biotransform
==================

A small, extensible toolkit that pulls compound / reaction / enzyme
evidence from EMBL-EBI resources (ChEBI, Rhea, UniProt, ChEMBL),
integrates it into a single evidence graph, scores candidate
biotransformations for a query compound, and renders the evidence
behind each prediction.

See README.md for the architecture and how to extend it.
"""

from .fetchers import ChEBIClient, RheaClient, UniProtClient, ChEMBLClient, MGnifyClient
from .mgnipy_client import MGnipySource
from .reference import load_reference_associations
from .integrate import EvidenceGraph
from .predict import BiotransformationPredictor, BiotransformationPrediction
from .visualize import plot_evidence_graph, plot_evidence_scores

__all__ = [
    "ChEBIClient",
    "RheaClient",
    "UniProtClient",
    "ChEMBLClient",
    "MGnifyClient",
    "MGnipySource",
    "load_reference_associations",
    "EvidenceGraph",
    "BiotransformationPredictor",
    "BiotransformationPrediction",
    "plot_evidence_graph",
    "plot_evidence_scores",
]

__version__ = "0.1.0"
